/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _src_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../src/styles/globals.css */ \"./src/styles/globals.css\");\n/* harmony import */ var _src_styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_src_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ \"next/head\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/script */ \"./node_modules/next/script.js\");\n/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\nfunction MyApp({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_script__WEBPACK_IMPORTED_MODULE_3___default()), {\n                id: \"track-pageview-pixel\",\n                src: \"https://connect.facebook.net/en_US/fbevents.js\",\n                onLoad: ()=>{\n                // fbq('init', '230622039592089');\n                // fbq('track', 'PageView');\n                }\n            }, void 0, false, {\n                fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                lineNumber: 8,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_script__WEBPACK_IMPORTED_MODULE_3___default()), {\n                id: \"vercel-speed-insights\",\n                src: \"/_vercel/insights/script.js\"\n            }, void 0, false, {\n                fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                lineNumber: 16,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"meta\", {\n                        charSet: \"UTF-8\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                        lineNumber: 21,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"meta\", {\n                        name: \"viewport\",\n                        content: \"width=device-width, initial-scale=1.0\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                        lineNumber: 22,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"title\", {\n                        children: \"Neuro Notion ┃ The Ultimate ADHD Study Notion Template\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                        lineNumber: 23,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"link\", {\n                        rel: \"icon\",\n                        href: \"https://raw.githubusercontent.com/joshiebudd/notionwidgets/main/logo.webp\",\n                        type: \"image/webp\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                        lineNumber: 24,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"style\", {\n                        children: \".hero-section{margin-bottom:50px;} .star-rating{margin-bottom:50px;} .centered-image{display:block;margin-left:auto;margin-right:auto;max-width:100%;height:auto;} .full-header{z-index:10;} h3{color:black;}\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                        lineNumber: 25,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"link\", {\n                        rel: \"dns-prefetch\",\n                        href: \"https://connect.facebook.net\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                        lineNumber: 28,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"link\", {\n                        rel: \"preconnect\",\n                        href: \"https://connect.facebook.net\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                        lineNumber: 29,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"link\", {\n                        rel: \"preload\",\n                        href: \"https://raw.githubusercontent.com/joshiebudd/notionwidgets/main/logo.webp\",\n                        as: \"image\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                        lineNumber: 30,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"link\", {\n                        rel: \"preload\",\n                        href: \"https://raw.githubusercontent.com/joshiebudd/notionwidgets/main/maindemo.webp\",\n                        as: \"image\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                        lineNumber: 31,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"link\", {\n                        rel: \"preload\",\n                        href: \"https://res.cloudinary.com/dc143mtxk/image/upload/v1705354011/jsnvus7ysm6uhencdf5a.png\",\n                        as: \"image\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                        lineNumber: 32,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"script\", {\n                        dangerouslySetInnerHTML: {\n                            __html: `\r\n              !function(t,e){var o,n,p,r;e.__SV||(window.posthog=e,e._i=[],e.init=function(i,s,a){function g(t,e){var o=e.split(\".\");2==o.length&&(t=t[o[0]],e=o[1]),t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}}(p=t.createElement(\"script\")).type=\"text/javascript\",p.async=!0,p.src=s.api_host+\"/static/array.js\",(r=t.getElementsByTagName(\"script\")[0]).parentNode.insertBefore(p,r);var u=e;for(void 0!==a?u=e[a]=[]:a=\"posthog\",u.people=u.people||[],u.toString=function(t){var e=\"posthog\";return\"posthog\"!==a&&(e+=\".\"+a),t||(e+=\" (stub)\"),e},u.people.toString=function(){return u.toString(1)+\".people (stub)\"},o=\"capture identify alias people.set people.set_once set_config register register_once unregister opt_out_capturing has_opted_out_capturing opt_in_capturing reset isFeatureEnabled onFeatureFlags getFeatureFlag getFeatureFlagPayload reloadFeatureFlags group updateEarlyAccessFeatureEnrollment getEarlyAccessFeatures getActiveMatchingSurveys getSurveys onSessionId\".split(\" \"),n=0;n<o.length;n++)g(u,o[n]);e._i.push([i,s,a])},e.__SV=1)}(document,window.posthog||[]);\r\n              posthog.init('phc_3lTf840WFEVTYO7GoU20Happ4w4r4YZLpeZuzwVWd7o',{api_host:'https://eu.posthog.com'});\r\n            `\n                        }\n                    }, void 0, false, {\n                        fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                        lineNumber: 34,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                lineNumber: 20,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"D:\\\\Upwork projects\\\\nextjsneuro\\\\pages\\\\_app.js\",\n                lineNumber: 44,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBbUM7QUFDTjtBQUNJO0FBRWpDLFNBQVNFLE1BQU0sRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDckMscUJBQ0U7OzBCQUNFLDhEQUFDSCxvREFBTUE7Z0JBQ0xJLElBQUc7Z0JBQ0hDLEtBQUk7Z0JBQ0pDLFFBQVE7Z0JBQ04sa0NBQWtDO2dCQUNsQyw0QkFBNEI7Z0JBQzlCOzs7Ozs7MEJBRUYsOERBQUNOLG9EQUFNQTtnQkFDTEksSUFBRztnQkFDSEMsS0FBSTs7Ozs7OzBCQUVOLDhEQUFDTixrREFBSUE7O2tDQUNILDhEQUFDUTt3QkFBS0MsU0FBUTs7Ozs7O2tDQUNkLDhEQUFDRDt3QkFBS0UsTUFBSzt3QkFBV0MsU0FBUTs7Ozs7O2tDQUM5Qiw4REFBQ0M7a0NBQU07Ozs7OztrQ0FDUCw4REFBQ0M7d0JBQUtDLEtBQUk7d0JBQU9DLE1BQUs7d0JBQTRFQyxNQUFLOzs7Ozs7a0NBQ3ZHLDhEQUFDQztrQ0FDRTs7Ozs7O2tDQUVILDhEQUFDSjt3QkFBS0MsS0FBSTt3QkFBZUMsTUFBSzs7Ozs7O2tDQUM5Qiw4REFBQ0Y7d0JBQUtDLEtBQUk7d0JBQWFDLE1BQUs7Ozs7OztrQ0FDNUIsOERBQUNGO3dCQUFLQyxLQUFJO3dCQUFVQyxNQUFLO3dCQUE0RUcsSUFBRzs7Ozs7O2tDQUN4Ryw4REFBQ0w7d0JBQUtDLEtBQUk7d0JBQVVDLE1BQUs7d0JBQWdGRyxJQUFHOzs7Ozs7a0NBQzVHLDhEQUFDTDt3QkFBS0MsS0FBSTt3QkFBVUMsTUFBSzt3QkFBeUZHLElBQUc7Ozs7OztrQ0FFckgsOERBQUNDO3dCQUNDQyx5QkFBeUI7NEJBQ3ZCQyxRQUFRLENBQUM7OztZQUdULENBQUM7d0JBQ0g7Ozs7Ozs7Ozs7OzswQkFJSiw4REFBQ2xCO2dCQUFXLEdBQUdDLFNBQVM7Ozs7Ozs7O0FBRzlCO0FBRUEsaUVBQWVGLEtBQUtBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1uZXh0LWFwcC8uL3BhZ2VzL19hcHAuanM/ZTBhZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJy4uL3NyYy9zdHlsZXMvZ2xvYmFscy5jc3MnO1xyXG5pbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnO1xyXG5pbXBvcnQgU2NyaXB0IGZyb20gJ25leHQvc2NyaXB0JztcclxuXHJcbmZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8U2NyaXB0XHJcbiAgICAgICAgaWQ9XCJ0cmFjay1wYWdldmlldy1waXhlbFwiXHJcbiAgICAgICAgc3JjPVwiaHR0cHM6Ly9jb25uZWN0LmZhY2Vib29rLm5ldC9lbl9VUy9mYmV2ZW50cy5qc1wiXHJcbiAgICAgICAgb25Mb2FkPXsoKSA9PiB7XHJcbiAgICAgICAgICAvLyBmYnEoJ2luaXQnLCAnMjMwNjIyMDM5NTkyMDg5Jyk7XHJcbiAgICAgICAgICAvLyBmYnEoJ3RyYWNrJywgJ1BhZ2VWaWV3Jyk7XHJcbiAgICAgICAgfX1cclxuICAgICAgLz5cclxuICAgICAgPFNjcmlwdFxyXG4gICAgICAgIGlkPVwidmVyY2VsLXNwZWVkLWluc2lnaHRzXCJcclxuICAgICAgICBzcmM9XCIvX3ZlcmNlbC9pbnNpZ2h0cy9zY3JpcHQuanNcIlxyXG4gICAgICAvPlxyXG4gICAgICA8SGVhZD5cclxuICAgICAgICA8bWV0YSBjaGFyU2V0PVwiVVRGLThcIiAvPlxyXG4gICAgICAgIDxtZXRhIG5hbWU9XCJ2aWV3cG9ydFwiIGNvbnRlbnQ9XCJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MS4wXCIgLz5cclxuICAgICAgICA8dGl0bGU+TmV1cm8gTm90aW9uIOKUgyBUaGUgVWx0aW1hdGUgQURIRCBTdHVkeSBOb3Rpb24gVGVtcGxhdGU8L3RpdGxlPlxyXG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2pvc2hpZWJ1ZGQvbm90aW9ud2lkZ2V0cy9tYWluL2xvZ28ud2VicFwiIHR5cGU9XCJpbWFnZS93ZWJwXCIgLz5cclxuICAgICAgICA8c3R5bGU+XHJcbiAgICAgICAgICB7Jy5oZXJvLXNlY3Rpb257bWFyZ2luLWJvdHRvbTo1MHB4O30gLnN0YXItcmF0aW5ne21hcmdpbi1ib3R0b206NTBweDt9IC5jZW50ZXJlZC1pbWFnZXtkaXNwbGF5OmJsb2NrO21hcmdpbi1sZWZ0OmF1dG87bWFyZ2luLXJpZ2h0OmF1dG87bWF4LXdpZHRoOjEwMCU7aGVpZ2h0OmF1dG87fSAuZnVsbC1oZWFkZXJ7ei1pbmRleDoxMDt9IGgze2NvbG9yOmJsYWNrO30nfVxyXG4gICAgICAgIDwvc3R5bGU+XHJcbiAgICAgICAgPGxpbmsgcmVsPVwiZG5zLXByZWZldGNoXCIgaHJlZj1cImh0dHBzOi8vY29ubmVjdC5mYWNlYm9vay5uZXRcIiAvPlxyXG4gICAgICAgIDxsaW5rIHJlbD1cInByZWNvbm5lY3RcIiBocmVmPVwiaHR0cHM6Ly9jb25uZWN0LmZhY2Vib29rLm5ldFwiIC8+XHJcbiAgICAgICAgPGxpbmsgcmVsPVwicHJlbG9hZFwiIGhyZWY9XCJodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20vam9zaGllYnVkZC9ub3Rpb253aWRnZXRzL21haW4vbG9nby53ZWJwXCIgYXM9XCJpbWFnZVwiIC8+XHJcbiAgICAgICAgPGxpbmsgcmVsPVwicHJlbG9hZFwiIGhyZWY9XCJodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20vam9zaGllYnVkZC9ub3Rpb253aWRnZXRzL21haW4vbWFpbmRlbW8ud2VicFwiIGFzPVwiaW1hZ2VcIiAvPlxyXG4gICAgICAgIDxsaW5rIHJlbD1cInByZWxvYWRcIiBocmVmPVwiaHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vZGMxNDNtdHhrL2ltYWdlL3VwbG9hZC92MTcwNTM1NDAxMS9qc252dXM3eXNtNnVoZW5jZGY1YS5wbmdcIiBhcz1cImltYWdlXCIgLz5cclxuXHJcbiAgICAgICAgPHNjcmlwdFxyXG4gICAgICAgICAgZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw9e3tcclxuICAgICAgICAgICAgX19odG1sOiBgXHJcbiAgICAgICAgICAgICAgIWZ1bmN0aW9uKHQsZSl7dmFyIG8sbixwLHI7ZS5fX1NWfHwod2luZG93LnBvc3Rob2c9ZSxlLl9pPVtdLGUuaW5pdD1mdW5jdGlvbihpLHMsYSl7ZnVuY3Rpb24gZyh0LGUpe3ZhciBvPWUuc3BsaXQoXCIuXCIpOzI9PW8ubGVuZ3RoJiYodD10W29bMF1dLGU9b1sxXSksdFtlXT1mdW5jdGlvbigpe3QucHVzaChbZV0uY29uY2F0KEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGFyZ3VtZW50cywwKSkpfX0ocD10LmNyZWF0ZUVsZW1lbnQoXCJzY3JpcHRcIikpLnR5cGU9XCJ0ZXh0L2phdmFzY3JpcHRcIixwLmFzeW5jPSEwLHAuc3JjPXMuYXBpX2hvc3QrXCIvc3RhdGljL2FycmF5LmpzXCIsKHI9dC5nZXRFbGVtZW50c0J5VGFnTmFtZShcInNjcmlwdFwiKVswXSkucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUocCxyKTt2YXIgdT1lO2Zvcih2b2lkIDAhPT1hP3U9ZVthXT1bXTphPVwicG9zdGhvZ1wiLHUucGVvcGxlPXUucGVvcGxlfHxbXSx1LnRvU3RyaW5nPWZ1bmN0aW9uKHQpe3ZhciBlPVwicG9zdGhvZ1wiO3JldHVyblwicG9zdGhvZ1wiIT09YSYmKGUrPVwiLlwiK2EpLHR8fChlKz1cIiAoc3R1YilcIiksZX0sdS5wZW9wbGUudG9TdHJpbmc9ZnVuY3Rpb24oKXtyZXR1cm4gdS50b1N0cmluZygxKStcIi5wZW9wbGUgKHN0dWIpXCJ9LG89XCJjYXB0dXJlIGlkZW50aWZ5IGFsaWFzIHBlb3BsZS5zZXQgcGVvcGxlLnNldF9vbmNlIHNldF9jb25maWcgcmVnaXN0ZXIgcmVnaXN0ZXJfb25jZSB1bnJlZ2lzdGVyIG9wdF9vdXRfY2FwdHVyaW5nIGhhc19vcHRlZF9vdXRfY2FwdHVyaW5nIG9wdF9pbl9jYXB0dXJpbmcgcmVzZXQgaXNGZWF0dXJlRW5hYmxlZCBvbkZlYXR1cmVGbGFncyBnZXRGZWF0dXJlRmxhZyBnZXRGZWF0dXJlRmxhZ1BheWxvYWQgcmVsb2FkRmVhdHVyZUZsYWdzIGdyb3VwIHVwZGF0ZUVhcmx5QWNjZXNzRmVhdHVyZUVucm9sbG1lbnQgZ2V0RWFybHlBY2Nlc3NGZWF0dXJlcyBnZXRBY3RpdmVNYXRjaGluZ1N1cnZleXMgZ2V0U3VydmV5cyBvblNlc3Npb25JZFwiLnNwbGl0KFwiIFwiKSxuPTA7bjxvLmxlbmd0aDtuKyspZyh1LG9bbl0pO2UuX2kucHVzaChbaSxzLGFdKX0sZS5fX1NWPTEpfShkb2N1bWVudCx3aW5kb3cucG9zdGhvZ3x8W10pO1xyXG4gICAgICAgICAgICAgIHBvc3Rob2cuaW5pdCgncGhjXzNsVGY4NDBXRkVWVFlPN0dvVTIwSGFwcDR3NHI0WVpMcGVadXp3VldkN28nLHthcGlfaG9zdDonaHR0cHM6Ly9ldS5wb3N0aG9nLmNvbSd9KTtcclxuICAgICAgICAgICAgYCxcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9IZWFkPlxyXG5cclxuICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTXlBcHA7XHJcbiJdLCJuYW1lcyI6WyJIZWFkIiwiU2NyaXB0IiwiTXlBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJpZCIsInNyYyIsIm9uTG9hZCIsIm1ldGEiLCJjaGFyU2V0IiwibmFtZSIsImNvbnRlbnQiLCJ0aXRsZSIsImxpbmsiLCJyZWwiLCJocmVmIiwidHlwZSIsInN0eWxlIiwiYXMiLCJzY3JpcHQiLCJkYW5nZXJvdXNseVNldElubmVySFRNTCIsIl9faHRtbCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./src/styles/globals.css":
/*!********************************!*\
  !*** ./src/styles/globals.css ***!
  \********************************/
/***/ (() => {



/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc"], () => (__webpack_exec__("./pages/_app.js")));
module.exports = __webpack_exports__;

})();